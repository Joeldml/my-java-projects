public class RandomNumber {
    public static void main(String[] args) {

        int randomNumber = (int)(Math.random() * 100) + 1;

        System.out.println("Random Number: " + randomNumber);
    }
}