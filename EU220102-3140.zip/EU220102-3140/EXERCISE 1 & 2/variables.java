public class Variables {
    public static void main(String[] args) {

        int age = 21;
        double height = 1.75;
        boolean isStudent = true;

        System.out.println("Age: " + age);
        System.out.println("Height: " + height);
        System.out.println("Is Student: " + isStudent);

    }
}