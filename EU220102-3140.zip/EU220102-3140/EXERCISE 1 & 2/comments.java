public class Comments {
    public static void main(String[] args) {

        // This is a single-line comment
        System.out.println("Learning Java Comments");

        /*
         This is a multi-line comment.
         It can span several lines.
         It is useful for explaining larger sections of code.
        */

        System.out.println("Comments make code easier to understand.");

    }
}