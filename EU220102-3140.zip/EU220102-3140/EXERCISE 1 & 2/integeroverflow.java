public class OverflowExample {
    public static void main(String[] args) {

        int a = 2_000_000_000;
        int b = 1_000_000_000;

        int overflowResult = a + b;

        System.out.println("Using int:");
        System.out.println("Result = " + overflowResult);

        long x = 2_000_000_000L;
        long y = 1_000_000_000L;

        long correctResult = x + y;

        System.out.println("\nUsing long:");
        System.out.println("Result = " + correctResult);
    }
}