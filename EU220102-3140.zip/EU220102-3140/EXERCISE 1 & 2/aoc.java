import java.util.Scanner;

public class AreaCalculator {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter the radius: ");
        double radius = input.nextDouble();

        double area = Math.PI * radius * radius;

        System.out.println("Area of the circle = " + area);

        input.close();
    }
}