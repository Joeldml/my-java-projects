import java.util.ArrayList;

public class ListPrinter {

    // Generic method
    public static <T> void printList(ArrayList<T> list) {

        for (T item : list) {
            System.out.println(item);
        }
    }

    public static void main(String[] args) {

        ArrayList<String> names = new ArrayList<>();
        names.add("Joel");
        names.add("Grace");
        names.add("David");

        ArrayList<Integer> numbers = new ArrayList<>();
        numbers.add(10);
        numbers.add(20);
        numbers.add(30);

        System.out.println("Names:");
        printList(names);

        System.out.println("\nNumbers:");
        printList(numbers);
    }
}