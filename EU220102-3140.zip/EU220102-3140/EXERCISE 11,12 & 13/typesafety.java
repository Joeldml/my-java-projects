import java.util.ArrayList;

public class TypeSafety {

    public static void main(String[] args) {

        // Non-generic ArrayList
        ArrayList list = new ArrayList();

        list.add("Java");
        list.add(100);
        list.add(true);

        System.out.println("Non-Generic ArrayList:");
        for (Object item : list) {
            System.out.println(item);
        }

        System.out.println();

        // Generic ArrayList
        ArrayList<String> names = new ArrayList<>();

        names.add("Joel");
        names.add("Grace");

        // names.add(100);   // This causes a compile-time error

        System.out.println("Generic ArrayList:");
        for (String name : names) {
            System.out.println(name);
        }
    }
}