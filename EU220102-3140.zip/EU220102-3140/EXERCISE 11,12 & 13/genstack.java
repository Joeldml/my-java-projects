import java.util.ArrayList;

public class GenericStack<T> {

    private ArrayList<T> stack = new ArrayList<>();

    // Push method
    public void push(T item) {
        stack.add(item);
    }

    // Pop method
    public T pop() {

        if (stack.isEmpty()) {
            return null;
        }

        return stack.remove(stack.size() - 1);
    }

    public static void main(String[] args) {

        GenericStack<Integer> stack = new GenericStack<>();

        stack.push(10);
        stack.push(20);
        stack.push(30);

        System.out.println("Popped: " + stack.pop());
        System.out.println("Popped: " + stack.pop());
    }
}