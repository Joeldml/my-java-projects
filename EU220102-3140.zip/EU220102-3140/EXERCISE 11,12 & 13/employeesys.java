class Employee {

    String name;
    double salary;

    Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Salary: " + salary);
    }
}

class Manager extends Employee {

    String department;

    Manager(String name, double salary, String department) {
        super(name, salary);
        this.department = department;
    }

    @Override
    void displayInfo() {
        super.displayInfo();
        System.out.println("Department: " + department);
    }
}

class Developer extends Employee {

    String programmingLanguage;

    Developer(String name, double salary, String programmingLanguage) {
        super(name, salary);
        this.programmingLanguage = programmingLanguage;
    }

    @Override
    void displayInfo() {
        super.displayInfo();
        System.out.println("Language: " + programmingLanguage);
    }
}

public class EmployeeSystem {

    public static void main(String[] args) {

        Manager m = new Manager("Alice", 5000, "IT");
        Developer d = new Developer("Bob", 4000, "Java");

        m.displayInfo();
        System.out.println();

        d.displayInfo();
    }
}