class Person {

    String name;

    Person(String name) {
        this.name = name;
        System.out.println("Person constructor called");
    }
}

class Student extends Person {

    int age;

    Student(String name, int age) {
        super(name); // calls Person constructor
        this.age = age;
        System.out.println("Student constructor called");
    }

    void display() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
    }
}

public class ConstructorChaining {

    public static void main(String[] args) {

        Student s = new Student("Joel", 21);

        System.out.println();
        s.display();
    }
}