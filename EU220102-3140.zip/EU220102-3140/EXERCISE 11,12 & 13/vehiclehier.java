class Vehicle {

    String brand;

    Vehicle(String brand) {
        this.brand = brand;
    }

    void showInfo() {
        System.out.println("Brand: " + brand);
    }
}

class Car extends Vehicle {

    int speed;

    Car(String brand, int speed) {
        super(brand);
        this.speed = speed;
    }

    void showCarInfo() {
        showInfo();
        System.out.println("Speed: " + speed + " km/h");
    }
}

class Bicycle extends Vehicle {

    boolean hasGear;

    Bicycle(String brand, boolean hasGear) {
        super(brand);
        this.hasGear = hasGear;
    }

    void showBicycleInfo() {
        showInfo();
        System.out.println("Has Gear: " + hasGear);
    }
}

public class VehicleTest {

    public static void main(String[] args) {

        Car car = new Car("Toyota", 120);
        Bicycle bike = new Bicycle("Giant", true);

        car.showCarInfo();
        System.out.println();

        bike.showBicycleInfo();
    }
}