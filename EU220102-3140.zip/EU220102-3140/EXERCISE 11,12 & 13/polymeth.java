class Shape {

    double getArea() {
        return 0;
    }
}

class Circle extends Shape {
    double radius;

    Circle(double radius) {
        this.radius = radius;
    }

    @Override
    double getArea() {
        return Math.PI * radius * radius;
    }
}

class Rectangle extends Shape {
    double length, width;

    Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }

    @Override
    double getArea() {
        return length * width;
    }
}

public class PolymorphicMethod {

    // Polymorphic method
    static void printArea(Shape shape) {
        System.out.println("Area = " + shape.getArea());
    }

    public static void main(String[] args) {

        Circle c = new Circle(4);
        Rectangle r = new Rectangle(6, 3);

        printArea(c);
        printArea(r);
    }
}