class Shape {

    double getArea() {
        return 0;
    }
}

class Circle extends Shape {

    double radius;

    Circle(double radius) {
        this.radius = radius;
    }

    @Override
    double getArea() {
        return Math.PI * radius * radius;
    }
}

class Rectangle extends Shape {

    double length, width;

    Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }

    @Override
    double getArea() {
        return length * width;
    }
}

public class ShapeTest {

    public static void main(String[] args) {

        Shape circle = new Circle(7);
        Shape rectangle = new Rectangle(10, 5);

        System.out.println("Circle Area = " + circle.getArea());
        System.out.println("Rectangle Area = " + rectangle.getArea());
    }
}