public class Pair<K, V> {

    private K key;
    private V value;

    // Constructor
    public Pair(K key, V value) {
        this.key = key;
        this.value = value;
    }

    // Getters
    public K getKey() {
        return key;
    }

    public V getValue() {
        return value;
    }

    public static void main(String[] args) {

        Pair<String, Integer> student = new Pair<>("Joel", 101);

        System.out.println("Key: " + student.getKey());
        System.out.println("Value: " + student.getValue());
    }
}