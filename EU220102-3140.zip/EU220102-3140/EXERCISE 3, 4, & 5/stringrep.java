import java.util.Scanner;

public class StringRepeater {

    // Method to repeat a string
    public static String repeatString(String text, int times) {

        String result = "";

        for (int i = 0; i < times; i++) {
            result += text;
        }

        return result;
    }

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String text = input.nextLine();

        System.out.print("Enter the number of times to repeat: ");
        int times = input.nextInt();

        System.out.println("Result: " + repeatString(text, times));

        input.close();
    }
}