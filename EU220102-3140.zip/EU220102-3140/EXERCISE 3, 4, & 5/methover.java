import java.util.Scanner;

public class MethodOverloading {

    // Area of a circle
    public static double area(double radius) {
        return Math.PI * radius * radius;
    }

    // Area of a rectangle
    public static double area(double length, double width) {
        return length * width;
    }

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter the radius of the circle: ");
        double radius = input.nextDouble();

        System.out.print("Enter the length of the rectangle: ");
        double length = input.nextDouble();

        System.out.print("Enter the width of the rectangle: ");
        double width = input.nextDouble();

        System.out.println("Area of Circle = " + area(radius));
        System.out.println("Area of Rectangle = " + area(length, width));

        input.close();
    }
}