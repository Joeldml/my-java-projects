import java.util.Scanner;

public class CharacterAnalysis {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String text = input.nextLine();

        System.out.println("\nCharacter\tASCII Value");

        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            int ascii = (int) ch;

            System.out.println(ch + "\t\t" + ascii);
        }

        input.close();
    }
}