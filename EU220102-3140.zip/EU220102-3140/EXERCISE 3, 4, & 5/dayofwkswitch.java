import java.util.Scanner;

public class DayOfWeek {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter a day number (1-7): ");
        int day = input.nextInt();

        switch (day) {
            case 1:
                System.out.println("Monday - Start of the work week.");
                break;
            case 2:
                System.out.println("Tuesday - Keep going!");
                break;
            case 3:
                System.out.println("Wednesday - Midweek.");
                break;
            case 4:
                System.out.println("Thursday - Almost the weekend.");
                break;
            case 5:
                System.out.println("Friday - Weekend is near!");
                break;
            case 6:
                System.out.println("Saturday - Enjoy your weekend.");
                break;
            case 7:
                System.out.println("Sunday - Rest and prepare for the week.");
                break;
            default:
                System.out.println("Invalid day number!");
        }

        input.close();
    }
}