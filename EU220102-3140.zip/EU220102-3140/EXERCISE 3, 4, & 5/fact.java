import java.util.Scanner;

public class Factorial {

    // Method to calculate factorial
    public static long factorial(int number) {
        long result = 1;

        for (int i = 1; i <= number; i++) {
            result *= i;
        }

        return result;
    }

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int number = input.nextInt();

        System.out.println("Factorial = " + factorial(number));

        input.close();
    }
}