public class Book {

    String title;
    String author;

    // Constructor
    Book(String title, String author) {
        this.title = title;
        this.author = author;
    }

    // Method to display details
    void displayDetails() {
        System.out.println("Book Title: " + title);
        System.out.println("Author: " + author);
    }

    public static void main(String[] args) {

        Book book1 = new Book("Java Programming", "John Smith");

        book1.displayDetails();
    }
}