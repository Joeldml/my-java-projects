import java.util.Scanner;

public class ReverseString {

    // Recursive method
    public static String reverse(String text) {

        if (text.isEmpty())
            return text;

        return reverse(text.substring(1)) + text.charAt(0);
    }

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String text = input.nextLine();

        System.out.println("Reversed String: " + reverse(text));

        input.close();
    }
}