class Item {

    String name;
    int quantity;

    Item(String name, int quantity) {
        this.name = name;
        this.quantity = quantity;
    }

    void display() {
        System.out.println("Item: " + name);
        System.out.println("Quantity: " + quantity);
    }
}

public class Inventory {

    public static void main(String[] args) {

        Item item1 = new Item("Laptop", 10);
        Item item2 = new Item("Mouse", 25);
        Item item3 = new Item("Keyboard", 15);

        item1.display();
        System.out.println();

        item2.display();
        System.out.println();

        item3.display();
    }
}