public class MaxElement {
    public static void main(String[] args) {

        int[] numbers = {25, 18, 90, 12, 65, 43};

        int max = numbers[0];

        for (int i = 1; i < numbers.length; i++) {

            if (numbers[i] > max) {
                max = numbers[i];
            }

        }

        System.out.println("Maximum element = " + max);
    }
}