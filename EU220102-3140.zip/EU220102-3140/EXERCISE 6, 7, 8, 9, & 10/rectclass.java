public class Rectangle {

    double width;
    double height;

    // Constructor
    Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }

    // Method to calculate area
    double area() {
        return width * height;
    }

    // Method to calculate perimeter
    double perimeter() {
        return 2 * (width + height);
    }

    public static void main(String[] args) {

        Rectangle rect = new Rectangle(10, 5);

        System.out.println("Width: " + rect.width);
        System.out.println("Height: " + rect.height);
        System.out.println("Area = " + rect.area());
        System.out.println("Perimeter = " + rect.perimeter());
    }
}