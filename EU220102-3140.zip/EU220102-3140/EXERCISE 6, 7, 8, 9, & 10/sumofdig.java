import java.util.Scanner;

public class SumOfDigits {

    // Recursive method
    public static int sumDigits(int number) {

        if (number == 0)
            return 0;

        return (number % 10) + sumDigits(number / 10);
    }

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int number = input.nextInt();

        System.out.println("Sum of digits = " + sumDigits(number));

        input.close();
    }
}