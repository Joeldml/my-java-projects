public class StudentManager {

    String name;
    int age;
    String department;

    // Constructor
    StudentManager(String name, int age, String department) {
        this.name = name;
        this.age = age;
        this.department = department;
    }

    // Method to display details
    void displayStudent() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Department: " + department);
        System.out.println();
    }

    public static void main(String[] args) {

        StudentManager student1 = new StudentManager("Joel", 21, "Cybersecurity");
        StudentManager student2 = new StudentManager("Grace", 20, "Computer Science");
        StudentManager student3 = new StudentManager("David", 22, "Information Technology");

        student1.displayStudent();
        student2.displayStudent();
        student3.displayStudent();
    }
}