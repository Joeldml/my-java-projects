public class Car {

    // Private fields
    private String model;
    private int speed;

    // Constructor
    public Car(String model, int speed) {
        this.model = model;
        this.speed = speed;
    }

    // Accelerate method
    public void accelerate(int increase) {
        speed += increase;
    }

    // Brake method
    public void brake(int decrease) {
        speed -= decrease;

        if (speed < 0) {
            speed = 0;
        }
    }

    // Display details
    public void display() {
        System.out.println("Model: " + model);
        System.out.println("Speed: " + speed + " km/h");
    }

    public static void main(String[] args) {

        Car car = new Car("Toyota Corolla", 60);

        car.display();

        car.accelerate(20);
        System.out.println("\nAfter Accelerating:");
        car.display();

        car.brake(30);
        System.out.println("\nAfter Braking:");
        car.display();
    }
}