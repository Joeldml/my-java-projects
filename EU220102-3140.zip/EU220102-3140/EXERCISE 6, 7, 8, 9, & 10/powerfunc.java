import java.util.Scanner;

public class PowerFunction {

    // Recursive method
    public static long power(int base, int exponent) {

        if (exponent == 0)
            return 1;

        return base * power(base, exponent - 1);
    }

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter the base: ");
        int base = input.nextInt();

        System.out.print("Enter the exponent: ");
        int exponent = input.nextInt();

        System.out.println(base + "^" + exponent + " = " + power(base, exponent));

        input.close();
    }
}