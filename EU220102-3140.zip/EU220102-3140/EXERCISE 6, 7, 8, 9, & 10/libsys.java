class Book {

    String title;
    boolean borrowed;

    Book(String title) {
        this.title = title;
        borrowed = false;
    }

    void borrowBook() {
        if (!borrowed) {
            borrowed = true;
            System.out.println(title + " has been borrowed.");
        } else {
            System.out.println(title + " is already borrowed.");
        }
    }

    void returnBook() {
        borrowed = false;
        System.out.println(title + " has been returned.");
    }
}

public class Library {

    public static void main(String[] args) {

        Book book1 = new Book("Java Programming");
        Book book2 = new Book("Data Structures");

        book1.borrowBook();
        book1.borrowBook();

        book1.returnBook();

        book2.borrowBook();
    }
}