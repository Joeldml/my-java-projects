class Shape {

    public void area() {
        System.out.println("Calculating Area...");
    }
}

class Circle extends Shape {

    double radius;

    Circle(double radius) {
        this.radius = radius;
    }

    @Override
    public void area() {
        System.out.println("Area of Circle = " + (Math.PI * radius * radius));
    }
}

class Rectangle extends Shape {

    double length, width;

    Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }

    @Override
    public void area() {
        System.out.println("Area of Rectangle = " + (length * width));
    }
}

public class ShapeTest {

    public static void main(String[] args) {

        Circle circle = new Circle(7);
        Rectangle rectangle = new Rectangle(10, 5);

        circle.area();
        rectangle.area();
    }
}