import java.util.Scanner;

public class NumberGuesser {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        int randomNumber = (int)(Math.random() * 100) + 1;
        int guess = 0;

        System.out.println("Guess a number between 1 and 100.");

        while (guess != randomNumber) {

            System.out.print("Enter your guess: ");
            guess = input.nextInt();

            if (guess < randomNumber) {
                System.out.println("Too low! Try again.");
            } else if (guess > randomNumber) {
                System.out.println("Too high! Try again.");
            } else {
                System.out.println("Congratulations! You guessed the correct number.");
            }
        }

        input.close();
    }
}