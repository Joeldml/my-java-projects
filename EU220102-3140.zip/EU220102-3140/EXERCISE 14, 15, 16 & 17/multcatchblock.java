import java.util.Scanner;

public class MultipleCatch {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        try {
            System.out.print("Enter a number: ");
            int num = input.nextInt();

            int result = 100 / num;
            System.out.println("Result = " + result);

            int[] arr = {1, 2, 3};
            System.out.println(arr[5]); // This may cause ArrayIndexOutOfBoundsException

        } catch (ArithmeticException e) {
            System.out.println("Error: Division by zero not allowed!");

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Error: Array index is out of range!");

        } catch (Exception e) {
            System.out.println("General error occurred!");
        }

        input.close();
    }
}