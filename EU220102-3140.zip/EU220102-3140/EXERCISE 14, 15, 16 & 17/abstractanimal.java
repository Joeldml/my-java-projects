abstract class Animal {

    abstract void makeSound();

    void sleep() {
        System.out.println("Animal is sleeping...");
    }
}

class Dog extends Animal {

    @Override
    void makeSound() {
        System.out.println("Dog says: Woof Woof");
    }
}

class Cat extends Animal {

    @Override
    void makeSound() {
        System.out.println("Cat says: Meow");
    }
}

public class AbstractAnimal {

    public static void main(String[] args) {

        Animal a1 = new Dog();
        Animal a2 = new Cat();

        a1.makeSound();
        a1.sleep();

        System.out.println();

        a2.makeSound();
        a2.sleep();
    }
}