abstract class BankAccount {

    double balance;

    BankAccount(double balance) {
        this.balance = balance;
    }

    abstract void withdraw(double amount);

    void deposit(double amount) {
        balance += amount;
        System.out.println("Deposited: " + amount);
    }

    void showBalance() {
        System.out.println("Balance = " + balance);
    }
}

class SavingsAccount extends BankAccount {

    SavingsAccount(double balance) {
        super(balance);
    }

    @Override
    void withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
            System.out.println("Withdrawn: " + amount);
        } else {
            System.out.println("Insufficient balance!");
        }
    }
}

class CurrentAccount extends BankAccount {

    CurrentAccount(double balance) {
        super(balance);
    }

    @Override
    void withdraw(double amount) {
        balance -= amount;
        System.out.println("Withdrawn: " + amount);
    }
}

public class BankSystem {

    public static void main(String[] args) {

        BankAccount acc1 = new SavingsAccount(1000);
        BankAccount acc2 = new CurrentAccount(2000);

        acc1.deposit(500);
        acc1.withdraw(1200);
        acc1.showBalance();

        System.out.println();

        acc2.withdraw(2500);
        acc2.showBalance();
    }
}