import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class WordCounter {

    public static void main(String[] args) {

        try {
            File file = new File("input.txt");
            Scanner reader = new Scanner(file);

            int wordCount = 0;

            while (reader.hasNext()) {
                reader.next(); // reads each word
                wordCount++;
            }

            reader.close();

            System.out.println("Total words in file = " + wordCount);

        } catch (FileNotFoundException e) {
            System.out.println("File not found!");
        }
    }
}