import java.util.Scanner;

// Custom Exception
class InvalidAgeException extends Exception {
    public InvalidAgeException(String message) {
        super(message);
    }
}

public class AgeValidator {

    static void checkAge(int age) throws InvalidAgeException {
        if (age < 0 || age > 120) {
            throw new InvalidAgeException("Age is invalid! Must be between 0 and 120.");
        } else {
            System.out.println("Valid age: " + age);
        }
    }

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        try {
            System.out.print("Enter your age: ");
            int age = input.nextInt();

            checkAge(age);

        } catch (InvalidAgeException e) {
            System.out.println("Exception: " + e.getMessage());
        }

        input.close();
    }
}