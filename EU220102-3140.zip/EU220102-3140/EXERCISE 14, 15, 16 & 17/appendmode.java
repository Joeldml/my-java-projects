import java.io.FileWriter;
import java.io.IOException;

public class AppendFile {

    public static void main(String[] args) {

        try {
            FileWriter writer = new FileWriter("data.txt", true); // true = append mode

            writer.write("New entry added\n");
            writer.write("Another record added\n");

            writer.close();

            System.out.println("Data appended successfully!");

        } catch (IOException e) {
            System.out.println("Error writing to file!");
        }
    }
}