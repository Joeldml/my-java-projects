import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class FileCopier {

    public static void main(String[] args) {

        try {
            File source = new File("source.txt");
            File destination = new File("destination.txt");

            Scanner reader = new Scanner(source);
            PrintWriter writer = new PrintWriter(destination);

            while (reader.hasNextLine()) {
                writer.println(reader.nextLine());
            }

            reader.close();
            writer.close();

            System.out.println("File copied successfully!");

        } catch (FileNotFoundException e) {
            System.out.println("Error: File not found!");
        }
    }
}