import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class StudentRecords {

    public static void main(String[] args) {

        try {
            FileWriter writer = new FileWriter("students.txt");

            writer.write("Joel - 85\n");
            writer.write("Grace - 90\n");
            writer.write("David - 78\n");

            writer.close();

            // Reading file
            File file = new File("students.txt");
            Scanner reader = new Scanner(file);

            System.out.println("Student Records:");

            while (reader.hasNextLine()) {
                System.out.println(reader.nextLine());
            }

            reader.close();

        } catch (IOException e) {
            System.out.println("Error handling file!");
        }
    }
}