abstract class Vehicle {

    String brand;

    Vehicle(String brand) {
        this.brand = brand;
    }

    abstract void start();

    void stop() {
        System.out.println(brand + " stopped.");
    }
}

class Car extends Vehicle {

    Car(String brand) {
        super(brand);
    }

    @Override
    void start() {
        System.out.println(brand + " car is starting...");
    }
}

class Truck extends Vehicle {

    Truck(String brand) {
        super(brand);
    }

    @Override
    void start() {
        System.out.println(brand + " truck is starting...");
    }
}

public class VehicleSystem {

    public static void main(String[] args) {

        Vehicle v1 = new Car("Toyota");
        Vehicle v2 = new Truck("Volvo");

        v1.start();
        v1.stop();

        System.out.println();

        v2.start();
        v2.stop();
    }
}