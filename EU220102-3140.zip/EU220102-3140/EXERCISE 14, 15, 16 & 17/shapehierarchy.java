abstract class Shape {

    abstract double getArea();
}

class Rectangle extends Shape {

    double length, width;

    Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }

    @Override
    double getArea() {
        return length * width;
    }
}

class Triangle extends Shape {

    double base, height;

    Triangle(double base, double height) {
        this.base = base;
        this.height = height;
    }

    @Override
    double getArea() {
        return 0.5 * base * height;
    }
}

public class ShapeTest {

    public static void main(String[] args) {

        Shape s1 = new Rectangle(10, 5);
        Shape s2 = new Triangle(8, 6);

        System.out.println("Rectangle Area = " + s1.getArea());
        System.out.println("Triangle Area = " + s2.getArea());
    }
}