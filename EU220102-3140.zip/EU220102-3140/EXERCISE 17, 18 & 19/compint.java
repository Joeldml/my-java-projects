import java.util.ArrayList;
import java.util.Collections;

class Student implements Comparable<Student> {

    String name;
    int age;

    Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    @Override
    public int compareTo(Student other) {
        return this.age - other.age; // sort by age
    }

    @Override
    public String toString() {
        return name + " (" + age + ")";
    }
}

public class ComparableTest {

    public static void main(String[] args) {

        ArrayList<Student> students = new ArrayList<>();

        students.add(new Student("Joel", 21));
        students.add(new Student("Grace", 19));
        students.add(new Student("David", 23));

        Collections.sort(students);

        System.out.println("Sorted by age:");
        for (Student s : students) {
            System.out.println(s);
        }
    }
}