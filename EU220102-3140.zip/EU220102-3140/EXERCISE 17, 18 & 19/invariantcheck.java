class BankAccount {

    private double balance;

    BankAccount(double balance) {
        this.balance = balance;
        assert balance >= 0 : "Initial balance cannot be negative";
    }

    void withdraw(double amount) {
        balance -= amount;

        // invariant check
        assert balance >= 0 : "Balance cannot be negative after withdrawal";
    }

    void deposit(double amount) {
        balance += amount;

        assert balance >= 0 : "Balance invariant violated";
    }

    void showBalance() {
        System.out.println("Balance = " + balance);
    }
}

public class InvariantCheck {

    public static void main(String[] args) {

        BankAccount acc = new BankAccount(100);

        acc.withdraw(50);
        acc.showBalance();

        acc.withdraw(100); // will break invariant
    }
}