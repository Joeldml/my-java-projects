import java.io.*;

class Book implements Serializable {

    String title;
    String author;
    double price;

    Book(String title, String author, double price) {
        this.title = title;
        this.author = author;
        this.price = price;
    }

    public String toString() {
        return title + " by " + author + " - $" + price;
    }
}

public class CustomObject {

    public static void main(String[] args) {

        Book b1 = new Book("Java Basics", "John Doe", 29.99);

        // SERIALIZE
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("book.ser"))) {
            out.writeObject(b1);
            System.out.println("Object serialized.");
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }

        // DESERIALIZE
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("book.ser"))) {

            Book readBook = (Book) in.readObject();
            System.out.println("Deserialized Object:");
            System.out.println(readBook);

        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}