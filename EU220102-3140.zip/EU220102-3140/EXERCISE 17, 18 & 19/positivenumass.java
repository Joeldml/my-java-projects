import java.util.Scanner;

public class PositiveNumber {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter a positive number: ");
        int num = input.nextInt();

        // Assertion check
        assert num > 0 : "Number must be positive!";

        System.out.println("Valid number: " + num);

        input.close();
    }
}