import java.io.*;
import java.util.ArrayList;

class Student implements Serializable {
    String name;
    int age;

    Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String toString() {
        return name + " (" + age + ")";
    }
}

public class SerializeList {

    public static void main(String[] args) {

        ArrayList<Student> list = new ArrayList<>();
        list.add(new Student("Joel", 21));
        list.add(new Student("Grace", 20));

        // SERIALIZATION
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("students.ser"))) {
            out.writeObject(list);
            System.out.println("List serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error writing file: " + e.getMessage());
        }

        // DESERIALIZATION
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("students.ser"))) {
            ArrayList<Student> readList = (ArrayList<Student>) in.readObject();

            System.out.println("\nDeserialized List:");
            for (Student s : readList) {
                System.out.println(s);
            }

        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }
}