interface Greeting {

    void sayHello();

    // Default method
    default void sayGoodbye() {
        System.out.println("Goodbye from interface!");
    }
}

class Person implements Greeting {

    @Override
    public void sayHello() {
        System.out.println("Hello from Person!");
    }
}

public class DefaultMethodTest {

    public static void main(String[] args) {

        Person p = new Person();

        p.sayHello();
        p.sayGoodbye(); // using default method
    }
}