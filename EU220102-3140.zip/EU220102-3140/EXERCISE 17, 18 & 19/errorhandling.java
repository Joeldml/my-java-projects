import java.io.*;

class User implements Serializable {

    private static final long serialVersionUID = 1L;

    String name;
    int age;

    User(String name, int age) {
        this.name = name;
        this.age = age;
    }
}

public class InvalidClassHandling {

    public static void main(String[] args) {

        // STEP 1: Serialize object
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("user.ser"))) {
            User u = new User("Joel", 21);
            out.writeObject(u);
            System.out.println("Object saved.");
        } catch (IOException e) {
            System.out.println("Write error: " + e.getMessage());
        }

        // STEP 2: Deserialize with error handling
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("user.ser"))) {

            User u = (User) in.readObject();
            System.out.println("User: " + u.name + ", " + u.age);

        } catch (InvalidClassException e) {
            System.out.println("InvalidClassException: Class structure changed!");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("General error: " + e.getMessage());
        }
    }
}