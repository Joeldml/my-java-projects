import java.io.*;

public class BinaryCounter {

    public static void main(String[] args) {

        int[] numbers = {10, 20, 30, 40, 50};

        // WRITE (binary file)
        try (DataOutputStream out = new DataOutputStream(new FileOutputStream("numbers.bin"))) {

            for (int num : numbers) {
                out.writeInt(num);
            }

            System.out.println("Numbers written to binary file.");

        } catch (IOException e) {
            System.out.println("Write error: " + e.getMessage());
        }

        // READ (binary file)
        try (DataInputStream in = new DataInputStream(new FileInputStream("numbers.bin"))) {

            System.out.println("\nReading numbers:");

            while (in.available() > 0) {
                System.out.println(in.readInt());
            }

        } catch (IOException e) {
            System.out.println("Read error: " + e.getMessage());
        }
    }
}