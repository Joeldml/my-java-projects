public class ArrayBounds {

    static int getElement(int[] arr, int index) {

        assert index >= 0 && index < arr.length : "Invalid array index";

        return arr[index];
    }

    public static void main(String[] args) {

        int[] numbers = {10, 20, 30, 40};

        System.out.println(getElement(numbers, 2)); // valid
        System.out.println(getElement(numbers, 10)); // invalid
    }
}