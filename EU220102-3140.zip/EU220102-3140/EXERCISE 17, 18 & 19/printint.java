interface Printable {
    void print();
}

class Book implements Printable {

    String title;

    Book(String title) {
        this.title = title;
    }

    @Override
    public void print() {
        System.out.println("Printing Book: " + title);
    }
}

class Document implements Printable {

    String name;

    Document(String name) {
        this.name = name;
    }

    @Override
    public void print() {
        System.out.println("Printing Document: " + name);
    }
}

public class PrintableTest {

    public static void main(String[] args) {

        Printable p1 = new Book("Java Basics");
        Printable p2 = new Document("Report.pdf");

        p1.print();
        p2.print();
    }
}