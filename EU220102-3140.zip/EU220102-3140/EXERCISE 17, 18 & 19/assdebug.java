public class AssertionDebug {

    public static void main(String[] args) {

        int[] numbers = {5, 10, 15};

        int sum = 0;

        for (int i = 0; i <= numbers.length; i++) { // BUG: should be i < length

            assert i < numbers.length : "Index out of bounds detected!";

            sum += numbers[i];
        }

        System.out.println("Sum = " + sum);
    }
}