interface Drawable {
    void draw();
}

interface Movable {
    void move();
}

class Robot implements Drawable, Movable {

    @Override
    public void draw() {
        System.out.println("Robot is being drawn on screen");
    }

    @Override
    public void move() {
        System.out.println("Robot is moving forward");
    }
}

public class MultiInterfaceTest {

    public static void main(String[] args) {

        Robot r = new Robot();

        r.draw();
        r.move();
    }
}